Config = {}

Config.Command = "marketplace" -- do /marketplace to open menu