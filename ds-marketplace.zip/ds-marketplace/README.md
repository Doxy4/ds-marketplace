# QB-MARKETPLACE

# IMPORT marketplace.sql FILE TO YOUR DATABASE
# Config.Lua to change basic stuff

# DISCORD: https://discord.gg/zmDVXxpBNx

